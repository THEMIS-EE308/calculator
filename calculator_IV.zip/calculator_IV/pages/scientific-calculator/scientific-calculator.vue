<template>
	<view class="">
		<uni-section title="科学计算器" type="line">
			<view class="example-body">
				<view class="nav-bar">
					<uni-icons type="list" size="22" @click="showDrawer('showLeft')"></uni-icons>
					<uni-icons type="wallet" size="22" @click="showDrawer('showRight')"></uni-icons>
				</view>
				<uni-drawer ref="showLeft" mode="left" :width="320" @change="change($event,'showLeft')">
					<view class="close">
						<button @click="closeDrawer('showLeft')" class="word-btn-white"><text>关闭Drawer</text></button>
					</view>
					<view class="close">
						<button @click="goPage1()" type="default" class="word-btn-white"><text>利率计算器</text></button>
					</view>
					<view class="close">
						<button @click="goPage2()" type="default" class="word-btn-white"><text>修改利率表信息</text></button>
					</view>
				</uni-drawer>
				<uni-drawer ref="showRight" mode="right" :mask-click="false" @change="change($event,'showRight')">
					<view class="scroll-view">
						<scroll-view class="scroll-view-box" scroll-y="true">
							<view class="close">
								<button @click="closeDrawer('showRight')" class="word-btn-white">
									<text>关闭Drawer</text>
								</button>
							</view>
							<view v-for="(item,index) in formulaList" :key="index">
								<text class="info">{{item.exp}} = {{item.res}}</text>
							</view>
							<!-- <view class="close">
								<button @click="closeDrawer('showRight')" class="word-btn-white"><text
										class="word-btn-white">关闭Drawer</text></button>
							</view> -->
						</scroll-view>
					</view>
				</uni-drawer>
			</view>

		</uni-section>
		<view class="calculator">
			<view class="display">{{ display }}</view>
			<view class="buttons">
				<view v-for="(row, rowIndex) in buttons" :key="rowIndex" class="button-row">
					<view v-for="(button, colIndex) in row" :key="colIndex"
						:class="['button', {'operator': '/+*-'.includes(button), 'ac': button === 'AC', 'equal': button === '='}]"
						@tap="handleButtonClick(button)">
						{{ button }}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				showRight: false,
				showLeft: false,
				display: '0',
				shouldClearResult: false,
				buttons: [
					['(', ')', 'sin', 'cos'],
					['tan', 'log', 'exp', 'sqrt'],
					['pi', 'e', '^', 'AC'],
					['7', '8', '9', '+'],
					['4', '5', '6', '-'],
					['1', '2', '3', '*'],
					['0', '.', '=', '/']
				],
				operatorClicked: false,
			};
		},
		onLoad() {
			this._initiExpList();
		},
		methods: {
			...mapMutations(['setformulaList']),
			handleButtonClick(button) {
				if (this.display === "0" || this.shouldClearResult) {
					this.display = '';
					this.shouldClearResult = false;
				}
				if (button === '=') {
					this.calculateResult();
				} else if (button === 'AC') {
					this.clearResult();
					this.shouldClearResult = false;
				} else {
					if (this.operatorClicked && /[0-9]/.test(button)) {
						this.display = button;
						this.operatorClicked = false;
					} else {
						this.display += button;
					}
				}
			},
			calculateResult() {
				try {
					this.display = this.display.replace(/sin/g, 'Math.sin');
					this.display = this.display.replace(/cos/g, 'Math.cos');
					this.display = this.display.replace(/tan/g, 'Math.tan');
					this.display = this.display.replace(/log/g, 'Math.log10');
					this.display = this.display.replace(/exp/g, 'Math.exp');
					this.display = this.display.replace(/sqrt/g, 'Math.sqrt');
					this.display = this.display.replace(/\^/g, '**');

					this.display = eval(this.display).toString();
					this.operatorClicked = true;
				} catch (error) {
					this.display = 'Error';
				}
			},
			clearResult() {
				this.display = '0';
				this.operatorClicked = false;
			},
			//跳转页面
			showDrawer(e) {
				this.$refs[e].open()
			},
			// 关闭窗口
			closeDrawer(e) {
				this.$refs[e].close()
			},
			// 抽屉状态发生变化触发
			change(e, type) {
				console.log((type === 'showLeft' ? '左窗口' : '右窗口') + (e ? '打开' : '关闭'));
				this[type] = e
			},
			async _initiExpList() {
				if (this.formulaList) return
				const formulaList = await this.$http.get_exp();
				if(formulaList){
					uni.showToast({
						title: '有问题，这个获取'
					})
				}
				this.setformulaList([...formulaList]);
			},
			goPage1(){
				uni.navigateTo({
					url:"/pages/profit-calc/profit-calc"
				})
			},
			goPage2(){
				uni.navigateTo({
					url:"/pages/profitInfo/profitInfo"
				})
			}
		},
		computed: {
			formulaList() {
				// console.log([...this.$store.state.formulaList][0]);
				return [...this.$store.state.formulaList];
			}
		}
	};
</script>

<style scoped>
	.calculator {
		display: flex;
		flex-direction: column;
		max-width: 320px;
		margin: auto;
		border: 1px solid #ddd;
		border-radius: 8px;
		overflow: hidden;
		box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
	}

	.display {
		font-size: 32px;
		background-color: #fff;
		color: #303030;
		padding: 20px;
		text-align: right;
		border-bottom: 1px solid #ddd;
	}

	.buttons {
		background-color: #f7f7f7;
		display: grid;
		grid-template-columns: repeat(4, 1fr);
		gap: 10px;
		padding: 10px;
	}

	.button-row {
		display: contents;
	}

	.button {
		font-size: 20px;
		padding: 15px 0;
		text-align: center;
		background-color: #e8e8e8;
		color: #333;
		border: none;
		border-radius: 7px;
		cursor: pointer;
		transition: background-color 0.3s;
	}

	.button:active {
		background-color: #d0d0d0;
	}

	.button.operator {
		background-color: #add8e6;
	}

	.button.operator:active {
		background-color: #97c0e0;
	}

	.button.ac,
	.button.equal {
		background-color: #ffcccb;
	}

	.button.ac,
	.button.equal:active {
		background-color: #f7b7b6;
	}

	.example-body {
		margin-bottom: 30rpx;
	}

	.nav-bar {
		display: flex;
		justify-content: space-between;
	}

	.word-btn-white {
		background-color: #fff;
	}
	
	.info{
		font-size: 32rpx;
		color: #888;
	}
</style>