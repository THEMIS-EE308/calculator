'use strict';
const db = uniCloud.database()
exports.main = async (event, context) => {
	const collection = db.collection('exp')
	const res = await collection.get()
	//返回数据给客户端
	console.log(res.data);
	return {
		code:0,
		data:res.data
	}
};
