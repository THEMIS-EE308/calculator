<template>
  <view class="interest-rate-list">
    <view class="header">
      <text class="title">利率列表</text>
    </view>
    <view class="list">
      <view v-for="(rate, index) in interestRates" :key="index" class="rate-item">
        <text class="name">{{ rate.name }}</text>
        <text class="value">{{ rate.value }}%</text>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      interestRates: [
        { name: '活期存款', value: 0.5 },
        { name: '定期存款（1年）', value: 1.5 },
        { name: '定期存款（3年）', value: 2.5 },
        // 可以根据需要添加更多利率信息
      ]
    };
  }
};
</script>

<style scoped lang="scss">
.interest-rate-list {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  // height: 100vh;
}

.header {
  margin-bottom: 20px;
}

.title {
  font-size: 24px;
  font-weight: bold;
}

.list {
  width: 80%;
}

.rate-item {
  display: flex;
  justify-content: space-between;
  padding: 10px;
  border-bottom: 1px solid #ccc;
}

.name {
  font-size: 18px;
}

.value {
  font-size: 18px;
  color: #337ab7;
}
</style>
