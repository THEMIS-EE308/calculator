<template>
	<view class="calculator ">
		<uni-section title="定期利率计算" type="line" style="height: calc(50vh - 100px);">
			<view class="item">
				<uni-easyinput v-model="principal" placeholder="本金(元)"></uni-easyinput>
			</view>
			<view class="item">
				<uni-data-picker placeholder="请选择期限" popup-title="请选择" :localdata="profitList_fixed" v-model="value"
					@change="onchange" @nodeclick="onnodeclick" @popupopened="onpopupopened"
					@popupclosed="onpopupclosed" @inputclick="inputclick"></uni-data-picker>
			</view>
			<view class="item">
				<uni-easyinput disabled v-model="interestRate" placeholder="利率值"></uni-easyinput>
			</view>
			<view class="item">
				<uni-easyinput v-model="fixedValue" placeholder="获利息值"></uni-easyinput>
			</view>
		</uni-section>
		<uni-section title="活期利率计算" type="line" style="height: calc(72vh - 100px);">
			<view class="item">
				<uni-easyinput v-model="currentPrincipal" placeholder="本金(元)"></uni-easyinput>
			</view>
			<view class="item">
				<uni-data-picker placeholder="请选择方式" popup-title="请选择" :localdata="profitList_current" v-model="value"
					@change="onchange" @nodeclick="onnodeclick" @popupopened="onpopupopened"
					@popupclosed="onpopupclosed" @inputclick="inputclick"></uni-data-picker>
			</view>
			<uni-section :title="'日期范围：' + '[' + range + ']'" type="line"></uni-section>
			<view class="item">
				<uni-datetime-picker v-model="range" type="daterange" @maskClick="maskClick" />
			</view>
			<view class="item">
				<uni-easyinput v-model="DateDiff" disabled placeholder="共计天数">{{DateDiff}}</uni-easyinput>
			</view>
			<view class="item">
				<uni-easyinput disabled v-model="currentInterestRate" placeholder="利率值(注:年)"></uni-easyinput>
			</view>
			<view class="item">
				<uni-easyinput v-model="currentValue" placeholder="获利息值(元)"></uni-easyinput>
			</view>
		</uni-section>
		<uni-section title="贷款利率计算" type="line" style="height: calc(60vh - 100px);">
			<view class="item">
				<uni-easyinput v-model="loansPrincipal" placeholder="本金(元)"></uni-easyinput>
			</view>
			<view class="item">
				<uni-data-picker placeholder="请选择期限" popup-title="请选择贷款方式" :localdata="profitList_loans" v-model="value"
					@change="onchange" @nodeclick="onnodeclick" @popupopened="onpopupopened"
					@popupclosed="onpopupclosed" @inputclick="inputclick"></uni-data-picker>
			</view>
			<view class="item">
				<uni-easyinput disabled v-model="loansInterestRate" placeholder="利率值"></uni-easyinput>
			</view>
			<view class="item">
				<uni-easyinput v-model="loansValue" placeholder="需还贷款值(元)"></uni-easyinput>
			</view>
		</uni-section>
		<!-- 展示利率表 -->
		<view class="interest-rate-list" style="height: calc(100vh - 100px);">
			<view class="header">
				<text class="title">利率列表</text>
			</view>
			<uni-section class="list fixed" title="定期利率表" type="circle" titleFontSize='40rpx' titleColor="#777">
				<view v-for="(item, index) in profitList_fixed" :key="index" class="rate-item">
					<text class="name">{{ item.text }}</text>
					<text class="value">{{ item.value }}%</text>
					<view class="item">
						<text v-model="currentValue" placeholder="获利息值(元)"></text>
					</view>
				</view>
			</uni-section>
			<uni-section class="list current" title="活期利率表" type="circle" titleFontSize='40rpx' titleColor="#777">
				<view v-for="(item, index) in profitList_current" :key="index" class="rate-item">
					<text class="name">{{ item.text }}</text>
					<text class="value">{{ item.value }}%</text>
				</view>
			</uni-section> 
			<uni-section class="list loans" title="贷款利率表" type="circle" titleFontSize='40rpx' titleColor="#777">
				<view v-for="(item, index) in profitList_loans" :key="index" class="rate-item">
					<text class="name">{{ item.text }}</text>
					<text class="value">{{ item.value }}%</text>
				</view>
			</uni-section>
		</view>
	</view>

</template>

<script>
	import {
		mapState,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				value: '',

				range: ['', ''],
				interestRate: '',
				loansterm: '',
				principal: '',
				interest: '',
				currentPrincipal: '',
				currentInterestRate: '',
				loansPrincipal: '',
				loansInterestRate: '',
				sDate1: "",
				sDate2: "",
			};
		},
		watch: {
			range(newval) {
				console.log('范围选:', this.range);
				this.sDate1 = this.range[0];
				this.sDate2 = this.range[1];
			},

		},
		onLoad() {
			this._intiProfitList();
		},
		computed: {
			profitList_fixed() {
				const fixed = [...this.$store.state.profitList.filter(item => item.type === "fixed")];
				// console.log(fixed);
				return fixed[0].option;
				// return [...this.$store.state.profitList.filter(item => item.type==="fixed")];
			},
			profitList_current() {
				// console.log(current);
				const current = [...this.$store.state.profitList.filter(item => item.type === "current")];
				return current[0].option;
			},
			profitList_loans() {
				// console.log(loans);
				const loans = [...this.$store.state.profitList.filter(item => item.type === "loans")];
				return loans[0].option;
				// return [...this.$store.state.profitList.filter(item => item.type==="current")];
			},
			DateDiff() {
				var aDate, oDate1, oDate2, iDays;
				aDate = this.sDate1.split("-");
				oDate1 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0]); //转换为yyyy-MM-dd格式
				aDate = this.sDate2.split("-");
				oDate2 = new Date(aDate[1] + '-' + aDate[2] + '-' + aDate[0]);
				iDays = parseInt(Math.abs(oDate1 - oDate2) / 1000 / 60 / 60 / 24); //把相差的毫秒数转换为天数
				return iDays + 1; //返回相差天数
			},
			//计算活期
			currentValue() {
				return this.currentPrincipal * this.DateDiff/365 * this.currentInterestRate / 100
			},
			//计算定期
			fixedValue() {
				return this.principal * this.term * this.interestRate / 100
			},
			//计算贷款
			loansValue() {
				return this.loansPrincipal * this.loansterm * this.loansInterestRate / 100
			}
		},
		methods: {
			...mapMutations(['setprofitList']),
			change(e) {
				console.log(e);
				return this.interestRate = e;
			},
			async _intiProfitList() {
				if (this.profitList) return
				const profitList = await this.$http.get_profit();
				this.setprofitList([...profitList]);

			},
			//
			onnodeclick(e) {
				if (e.text === "活期存款日利率") {
					this.interestRate = "";
					this.currentInterestRate = e.value;
					console.log('nodeclick', e);
				} else if (e.loans) {
					this.interestRate = "";
					this.loansterm = e.term;
					this.loansInterestRate = e.value,
					console.log('nodeclick', e);
				} else {
					this.term = e.term;
					this.currentInterestRate = "";
					this.interestRate = e.value;
					console.log('nodeclick', e);
				}

			},
			onpopupopened(e) {
				console.log('onpopupopened');
			},
			onpopupclosed(e) {
				console.log('onpopupclosed');
			},
			onchange(e) {
				console.log('onchange', e.detail.value);
			},
			inputclick(e) {
				console.log('inputclick', e);
			},
			maskClick(e) {
				console.log('maskClick事件:', e);
			},
		}
	};
</script>

<style scoped lang="scss">
	.calculator {
		display: flex;
		flex-direction: column;
		// align-items: center;
		justify-content: center;
		// height: 100vh;
	}

	.form {
		margin-bottom: 20px;
	}

	.label {
		font-size: 18px;
		margin-right: 10px;
	}

	.input {
		width: 150px;
		font-size: 18px;
		padding: 5px;
		border: 1px solid #ccc;
		border-radius: 5px;
	}

	.result {
		font-size: 18px;
		padding: 5px;
		border: 1px solid #ccc;
		border-radius: 5px;
		margin-top: 10px;
	}

	.item {
		margin-bottom: 30rpx;
	}

	.calculate-button {
		font-size: 18px;
		padding: 10px;
		background-color: #337ab7;
		color: #fff;
		border: none;
		border-radius: 5px;
		cursor: pointer;
	}

	//
	.container {
		/* padding: 0 15px; */
		/* #ifndef APP-NVUE */
		display: flex;
		max-width: 500px;
		/* #endif */
		flex-direction: column;
	}

	.title {
		font-size: 14px;
		font-weight: bold;
		margin: 20px 0 5px 0;
	}

	.input-border {
		border: 1px solid #b3e5fc;
		border-radius: 5px;
		padding: 2px 4px;
	}

	.input-selected {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		line-height: 2;
	}

	.data-pickerview {
		height: 300px;
		border: 1px solid #e5e5e5;
		border-radius: 5px;
		/* #ifndef APP-NVUE */
		overflow: hidden;
		/* #endif */
	}
	// 利率表样式
	.interest-rate-list {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		// height: 100vh;
	}
	
	.header {
		margin-bottom: 20px;
		
	}
	
	.title {
		font-size: 38rpx;
		font-weight: bold;
		color: #555;
	}
	
	.list {
		width: 80%;
	}
	
	.rate-item {
		display: flex;
		justify-content: space-between;
		padding: 10px;
		border-bottom: 1px solid #ccc;
	}
	
	.name {
		font-size: 18px;
	}
	
	.value {
		font-size: 18px;
		color: #337ab7;
	}
	.edit-input {
	  width: 80px;
	  margin-right: 10px;
	}
</style>