export default {
	userInfo: uni.getStorageSync('userInfo') || null,
	historyList: uni.getStorageSync('historyList') || [],
	labelList: uni.getStorageSync('labelList') || [], // 导航栏标签
	profitList: uni.getStorageSync('profitList') || [],
	formulaList: uni.getStorageSync('formulaList') || [
		{
			exp:"3+5",
			res:"8",
		},
		{
			exp:"3+5",
			res:"8",
		},
		{
			exp:"3+5",
			res:"8",
		},
		{
			exp:"3+5",
			res:"8",
		},
		{
			exp:"3+5",
			res:"8",
		}
	]
}