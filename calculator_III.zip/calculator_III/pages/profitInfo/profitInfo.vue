<template>
	<view class="interest-rate-list">
		<view class="header">
			<text class="title">利率列表</text>
		</view>
		<uni-section class="list fixed" title="定期利率表" type="circle" titleFontSize='40rpx' titleColor="#777">
			<view v-for="(item, index) in profitList_fixed" :key="index" class="rate-item">
				<text class="name">{{ item.text }}</text>
				<text class="value">{{ item.value }}%</text>
			</view>
		</uni-section>
		<uni-section class="list current" title="活期利率表" type="circle" titleFontSize='40rpx' titleColor="#777">
			<view v-for="(item, index) in profitList_current" :key="index" class="rate-item">
				<text class="name">{{ item.text }}</text>
				<text class="value">{{ item.value }}%</text>
			</view>
		</uni-section> 
		<uni-section class="list loans" title="贷款利率表" type="circle" titleFontSize='40rpx' titleColor="#777">
			<view v-for="(item, index) in profitList_loans" :key="index" class="rate-item">
				<text class="name">{{ item.text }}</text>
				<text class="value">{{ item.value }}%</text>
			</view>
		</uni-section>
	</view>
</template>

<script>
	import {
		mapState,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				value: '',
				principal: '',
				interest: '',
				currentPrincipal: '',
				currentInterestRate: '',
				currentInterest: '',
				interestRates: [{
						name: '活期存款',
						value: 0.5
					},
					{
						name: '定期存款（1年）',
						value: 1.5
					},
					{
						name: '定期存款（3年）',
						value: 2.5
					},
					// 可以根据需要添加更多利率信息
				]
			};
		},
		onLoad() {
			this._intiProfitList();
		},
		computed: {
			profitList_fixed() {
				const fixed = [...this.$store.state.profitList.filter(item => item.type === "fixed")];
				// console.log(fixed);
				return fixed[0].option;
				// return [...this.$store.state.profitList.filter(item => item.type==="fixed")];
			},
			profitList_current() {
				// console.log(current);
				const current = [...this.$store.state.profitList.filter(item => item.type === "current")];
				return current[0].option;
			},
			profitList_loans() {
				// console.log(loans);
				const loans = [...this.$store.state.profitList.filter(item => item.type === "loans")];
				return loans[0].option;
				// return [...this.$store.state.profitList.filter(item => item.type==="current")];
			},
		},
		methods: {
			...mapMutations(['setprofitList']),
			change(e) {
				console.log(e);
				return this.interestRate = e;
			},
			async _intiProfitList() {
				if (this.profitList) return
				const profitList = await this.$http.get_profit();
				this.setprofitList([...profitList]);
			},
			//
			onnodeclick(e) {
				if (e.text === "活期存款日利率") {
					this.interestRate = "";
					this.currentInterestRate = e.value;
					console.log('nodeclick', e);
				} else if (e.loans) {
					this.interestRate = "";
					this.loansterm = e.term;
					this.loansInterestRate = e.value,
					console.log('nodeclick', e);
				} else {
					this.term = e.term;
					this.currentInterestRate = "";
					this.interestRate = e.value;
					console.log('nodeclick', e);
				}
			
			},
			
			
		}
	};
</script>

<style scoped lang="scss">
	.interest-rate-list {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		// height: 100vh;
	}

	.header {
		margin-bottom: 20px;
		
	}

	.title {
		font-size: 38rpx;
		font-weight: bold;
		color: #555;
	}

	.list {
		width: 80%;
	}

	.rate-item {
		display: flex;
		justify-content: space-between;
		padding: 10px;
		border-bottom: 1px solid #ccc;
	}

	.name {
		font-size: 18px;
	}

	.value {
		font-size: 18px;
		color: #337ab7;
	}
</style>