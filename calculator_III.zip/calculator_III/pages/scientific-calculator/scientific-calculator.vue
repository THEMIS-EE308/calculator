<template>
  <view class="calculator">
    <view class="display">{{ display }}</view>
    <view class="buttons">
      <view v-for="(row, rowIndex) in buttons" :key="rowIndex" class="button-row">
        <view v-for="(button, colIndex) in row" :key="colIndex" class="button" @tap="handleButtonClick(button)">
          {{ button }}
        </view>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      display: '0',
	  shouldClearResult: false,
      buttons: [
        ['7', '8', '9', '/'],
        ['4', '5', '6', '*'],
        ['1', '2', '3', '-'],
        ['0', '.', '=', '+'],
        ['(', ')', 'sin', 'cos'],
        ['tan', 'log', 'exp', 'sqrt'],
        ['pi', 'e', '^', 'AC']
      ],
      operatorClicked: false
    };
  },
  methods: {
    handleButtonClick(button) {
      if (this.display==="0"||this.shouldClearResult) {
        this.display = '';
        this.shouldClearResult = false;
      }
	  if (button === '=') {
        this.calculateResult();
      } else if (button === 'AC') {
        this.clearResult();
		this.shouldClearResult = false;
      } else {
        if (this.operatorClicked && /[0-9]/.test(button)) {
          this.display = button;
          this.operatorClicked = false;
        } else {
          this.display += button;
        }
      }
    },
    calculateResult() {
      try {
        // 使用正则表达式替换更多的数学函数
        this.display = this.display.replace(/sin/g, 'Math.sin');
        this.display = this.display.replace(/cos/g, 'Math.cos');
        this.display = this.display.replace(/tan/g, 'Math.tan');
        this.display = this.display.replace(/log/g, 'Math.log10');
        this.display = this.display.replace(/exp/g, 'Math.exp');
        this.display = this.display.replace(/sqrt/g, 'Math.sqrt');
        this.display = this.display.replace(/\^/g, '**');
        
        // 计算结果
        this.display = eval(this.display).toString();
        this.operatorClicked = true;
      } catch (error) {
        this.display = 'Error';
      }
    },
    clearResult() {
      this.display = '0';
      this.operatorClicked = false;
    }
  }
};
</script>

<style scoped>
.calculator {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
}

.display {
  font-size: 24px;
  margin-bottom: 20px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.buttons {
  display: flex;
  flex-direction: column;
}

.button-row {
  display: flex;
}

.button {
  flex: 1;
  font-size: 18px;
  padding: 15px;
  margin: 5px;
  text-align: center;
  background-color: #337ab7;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
</style>
